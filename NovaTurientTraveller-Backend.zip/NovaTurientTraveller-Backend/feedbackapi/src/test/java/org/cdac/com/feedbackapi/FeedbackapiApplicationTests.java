package org.cdac.com.feedbackapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
