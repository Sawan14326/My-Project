package com.cdac.signupapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SignupapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SignupapiApplication.class, args);
	}

}
