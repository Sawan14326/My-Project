package com.cdac.signupapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignupapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
